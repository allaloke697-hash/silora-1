import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import type { Profile, Order } from '@/lib/types';
import { formatPrice, formatShortDate } from '@/lib/utils';
import ConfirmDialog from '@/components/ConfirmDialog';
import { Search, Users, ChevronRight, Mail, Phone, ShoppingBag, Loader2, Trash2, UserX, AlertCircle, Check } from 'lucide-react';

interface CustomerWithStats extends Profile {
  order_count: number;
  total_spent: number;
}

export default function AdminCustomers() {
  const [customers, setCustomers] = useState<CustomerWithStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerWithStats | null>(null);
  const [customerOrders, setCustomerOrders] = useState<Order[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cleanupLoading, setCleanupLoading] = useState(false);
  const [cleanupResult, setCleanupResult] = useState<string | null>(null);

  const fetchCustomers = async () => {
    const { data, error: err } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });

    if (err || !data) {
      setLoading(false);
      return;
    }

    const profiles = data as Profile[];
    const customerProfiles = profiles.filter((p) => p.role !== 'admin');

    const customersWithStats: CustomerWithStats[] = await Promise.all(
      customerProfiles.map(async (p) => {
        const { data: orders } = await supabase
          .from('orders')
          .select('total, payment_status')
          .eq('user_id', p.id);

        const paidOrders = (orders ?? []).filter((o) => o.payment_status === 'paid');
        return {
          ...p,
          order_count: orders?.length ?? 0,
          total_spent: paidOrders.reduce((sum, o) => sum + o.total, 0),
        };
      })
    );

    setCustomers(customersWithStats);
    setLoading(false);
  };

  useEffect(() => {
    fetchCustomers();
  }, []);

  const loadCustomerOrders = async (customer: CustomerWithStats) => {
    setSelectedCustomer(customer);
    setOrdersLoading(true);
    setError(null);
    const { data } = await supabase
      .from('orders')
      .select('*, order_items(*)')
      .eq('user_id', customer.id)
      .order('created_at', { ascending: false });

    setCustomerOrders((data as Order[]) ?? []);
    setOrdersLoading(false);
  };

  const handleDeleteCustomer = async () => {
    if (!selectedCustomer) return;
    setDeleting(true);
    setError(null);

    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const accessToken = sessionData?.session?.access_token;
      if (!accessToken) {
        setError('Your session has expired. Please sign in again.');
        setDeleting(false);
        setShowDeleteConfirm(false);
        return;
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-delete-user`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify({ userId: selectedCustomer.id }),
        }
      );

      if (!response.ok) {
        const errBody = await response.json().catch(() => ({ error: 'Deletion failed' }));
        throw new Error(errBody.error ?? `Deletion failed (${response.status})`);
      }

      const result = await response.json();
      if (!result.success) {
        throw new Error(result.error ?? 'Deletion failed');
      }

      setShowDeleteConfirm(false);
      setDeleting(false);
      setSelectedCustomer(null);
      setCustomerOrders([]);
      await fetchCustomers();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete customer.');
      setDeleting(false);
      setShowDeleteConfirm(false);
    }
  };

  const handleCleanupOrphans = async () => {
    setCleanupLoading(true);
    setError(null);
    setCleanupResult(null);

    const { data, error: cleanupError } = await supabase.rpc('admin_cleanup_orphaned_profiles');

    if (cleanupError) {
      setError(cleanupError.message);
    } else {
      const count = data as number;
      setCleanupResult(count > 0 ? `Removed ${count} orphaned profile(s).` : 'No orphaned profiles found.');
      await fetchCustomers();
    }
    setCleanupLoading(false);
  };

  const filtered = customers.filter((c) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      c.email.toLowerCase().includes(q) ||
      (c.full_name ?? '').toLowerCase().includes(q) ||
      (c.phone ?? '').toLowerCase().includes(q)
    );
  });

  if (loading) {
    return (
      <div className="text-center py-16">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-neutral-300 border-t-neutral-900 mx-auto" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
        <h1 className="text-2xl font-serif font-bold text-neutral-900">Customers</h1>
        <button
          onClick={handleCleanupOrphans}
          disabled={cleanupLoading}
          className="px-4 py-2 border border-neutral-300 rounded-lg text-sm font-medium text-neutral-700 hover:bg-neutral-50 transition-colors flex items-center gap-2"
        >
          {cleanupLoading ? <Loader2 size={16} className="animate-spin" /> : <UserX size={16} />}
          Clean up orphaned profiles
        </button>
      </div>

      {cleanupResult && (
        <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg text-sm text-green-700 flex items-center gap-2">
          <Check size={16} /> {cleanupResult}
        </div>
      )}

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700 flex items-start gap-2">
          <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Customer list */}
        <div className="lg:col-span-1">
          <div className="relative mb-4">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name, email, phone..."
              className="w-full pl-10 pr-4 py-2.5 border border-neutral-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-neutral-900 bg-white"
            />
          </div>

          {filtered.length === 0 ? (
            <div className="bg-white border border-neutral-200 rounded-lg p-8 text-center">
              <Users size={32} className="text-neutral-300 mx-auto mb-2" />
              <p className="text-sm text-neutral-500">No customers found.</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {filtered.map((c) => (
                <button
                  key={c.id}
                  onClick={() => loadCustomerOrders(c)}
                  className={`w-full text-left bg-white border rounded-lg p-4 hover:shadow-md transition-shadow ${
                    selectedCustomer?.id === c.id ? 'border-neutral-900 ring-1 ring-neutral-900' : 'border-neutral-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-neutral-900 truncate">
                        {c.full_name || c.email}
                      </p>
                      <p className="text-xs text-neutral-500 truncate">{c.email}</p>
                    </div>
                    <ChevronRight size={16} className="text-neutral-400 flex-shrink-0" />
                  </div>
                  <div className="flex items-center gap-3 mt-2 text-xs text-neutral-500">
                    <span>{c.order_count} {c.order_count === 1 ? 'order' : 'orders'}</span>
                    <span>{formatPrice(c.total_spent)} spent</span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Customer detail + orders */}
        <div className="lg:col-span-2">
          {!selectedCustomer ? (
            <div className="bg-white border border-neutral-200 rounded-lg p-12 text-center">
              <Users size={40} className="text-neutral-300 mx-auto mb-3" />
              <p className="text-neutral-500">Select a customer to view their details and orders.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Customer info */}
              <div className="bg-white border border-neutral-200 rounded-lg p-6">
                <div className="flex items-start justify-between mb-4">
                  <h2 className="text-lg font-semibold text-neutral-900">Customer Details</h2>
                  <button
                    onClick={() => setShowDeleteConfirm(true)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    title="Delete customer account"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
                <div className="grid sm:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-neutral-500 mb-1">Name</p>
                    <p className="font-medium text-neutral-900">{selectedCustomer.full_name || '—'}</p>
                  </div>
                  <div>
                    <p className="text-neutral-500 mb-1">Email</p>
                    <p className="font-medium text-neutral-900 flex items-center gap-1.5">
                      <Mail size={14} className="text-neutral-400" /> {selectedCustomer.email}
                    </p>
                  </div>
                  <div>
                    <p className="text-neutral-500 mb-1">Phone</p>
                    <p className="font-medium text-neutral-900 flex items-center gap-1.5">
                      <Phone size={14} className="text-neutral-400" /> {selectedCustomer.phone || '—'}
                    </p>
                  </div>
                  <div>
                    <p className="text-neutral-500 mb-1">Joined</p>
                    <p className="font-medium text-neutral-900">{formatShortDate(selectedCustomer.created_at)}</p>
                  </div>
                  <div>
                    <p className="text-neutral-500 mb-1">Total Orders</p>
                    <p className="font-medium text-neutral-900">{selectedCustomer.order_count}</p>
                  </div>
                  <div>
                    <p className="text-neutral-500 mb-1">Total Spent</p>
                    <p className="font-medium text-neutral-900">{formatPrice(selectedCustomer.total_spent)}</p>
                  </div>
                </div>
              </div>

              {/* Customer orders */}
              <div className="bg-white border border-neutral-200 rounded-lg p-6">
                <h2 className="text-lg font-semibold text-neutral-900 mb-4 flex items-center gap-2">
                  <ShoppingBag size={18} /> Orders
                </h2>

                {ordersLoading ? (
                  <div className="text-center py-8">
                    <Loader2 size={24} className="animate-spin text-neutral-400 mx-auto" />
                  </div>
                ) : customerOrders.length === 0 ? (
                  <p className="text-sm text-neutral-500 text-center py-8">No orders from this customer.</p>
                ) : (
                  <div className="space-y-3">
                    {customerOrders.map((order) => (
                      <Link
                        key={order.id}
                        to={`/admin/orders/${order.id}`}
                        className="flex items-center justify-between p-3 border border-neutral-200 rounded-lg hover:bg-neutral-50 transition-colors"
                      >
                        <div>
                          <p className="text-sm font-medium text-neutral-900">{order.order_number}</p>
                          <p className="text-xs text-neutral-500">{formatShortDate(order.created_at)}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-semibold text-neutral-900">{formatPrice(order.total)}</p>
                          <p className="text-xs text-neutral-500 capitalize">{order.order_status} · {order.payment_status.replace(/_/g, ' ')}</p>
                        </div>
                        <ChevronRight size={16} className="text-neutral-400 ml-2" />
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {showDeleteConfirm && selectedCustomer && (
        <ConfirmDialog
          title="Delete this customer account?"
          message={`This will permanently delete the account for ${selectedCustomer.email}. Their order history will be preserved for your records. The customer can sign up again with the same email and phone if needed. This cannot be undone.`}
          confirmLabel={deleting ? 'Deleting...' : 'Delete account'}
          onConfirm={handleDeleteCustomer}
          onCancel={() => setShowDeleteConfirm(false)}
        />
      )}
    </div>
  );
}
