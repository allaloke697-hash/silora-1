import { useEffect, useState, useRef } from 'react';
import { useAuth } from '@/lib/auth-context';
import { supabase } from '@/lib/supabase';
import type { StoreSettings, PaymentSettings } from '@/lib/types';
import { Loader2, Check, AlertCircle, Store, Smartphone, MessageSquare, Save, Truck, Mail, FileText, Image, CreditCard, QrCode, Upload, Trash2 } from 'lucide-react';

export default function AdminSettings() {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState<StoreSettings | null>(null);
  const [paySettings, setPaySettings] = useState<PaymentSettings | null>(null);
  const [uploadingQr, setUploadingQr] = useState(false);
  const [qrError, setQrError] = useState<string | null>(null);
  const [qrSuccess, setQrSuccess] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    (async () => {
      const { data, error: err } = await supabase
        .from('store_settings')
        .select('*')
        .eq('id', 1)
        .maybeSingle();

      if (err || !data) {
        setLoading(false);
        return;
      }
      setForm(data as StoreSettings);

      // Load payment QR settings
      const { data: payData } = await supabase
        .from('payment_settings')
        .select('*')
        .eq('id', 1)
        .maybeSingle();
      if (payData) setPaySettings(payData as PaymentSettings);

      setLoading(false);
    })();
  }, []);

  const update = (field: keyof StoreSettings, value: string | boolean | number) => {
    if (!form) return;
    setForm({ ...form, [field]: value });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form) return;
    setSaving(true);
    setError(null);

    const { error: updateError } = await supabase
      .from('store_settings')
      .update({
        store_name: form.store_name.trim(),
        upi_id: form.upi_id.trim(),
        payment_verification_window: form.payment_verification_window.trim(),
        shipping_type: 'free',
        flat_shipping_cost: 0,
        free_shipping_threshold: 0,
        contact_email: form.contact_email.trim(),
        contact_phone: form.contact_phone.trim(),
        contact_address: form.contact_address.trim(),
        return_policy: form.return_policy,
        shipping_policy: form.shipping_policy,
        privacy_policy: form.privacy_policy,
        terms_of_service: form.terms_of_service,
        hero_title: form.hero_title.trim(),
        hero_subtitle: form.hero_subtitle.trim(),
        hero_image: form.hero_image.trim(),
        banner_text: form.banner_text.trim(),
        banner_visible: form.banner_visible,
        upi_enabled: form.upi_enabled,
        cod_enabled: form.cod_enabled,
        payment_instructions: form.payment_instructions,
      })
      .eq('id', 1);

    if (updateError) {
      setError(updateError.message);
      setSaving(false);
      return;
    }

    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleQrUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setQrError(null);
    setQrSuccess(null);
    setUploadingQr(true);

    try {
      // Delete old QR from storage if exists
      if (paySettings?.qr_code_storage_path) {
        await supabase.storage.from('payment-qr').remove([paySettings.qr_code_storage_path]);
      }

      const ext = file.name.split('.').pop() || 'png';
      const filePath = `qr-${Date.now()}.${ext}`;

      const { error: uploadError } = await supabase.storage
        .from('payment-qr')
        .upload(filePath, file, { cacheControl: '3600', upsert: false });

      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage.from('payment-qr').getPublicUrl(filePath);
      const publicUrl = urlData.publicUrl;

      const { data: updated, error: dbError } = await supabase
        .from('payment_settings')
        .upsert({
          id: 1,
          qr_code_url: publicUrl,
          qr_code_storage_path: filePath,
          is_active: true,
          updated_at: new Date().toISOString(),
        })
        .select()
        .single();

      if (dbError) throw dbError;
      setPaySettings(updated as PaymentSettings);
      setQrSuccess('QR code uploaded and set as active.');
      setTimeout(() => setQrSuccess(null), 4000);
    } catch (err) {
      setQrError(err instanceof Error ? err.message : 'Failed to upload QR code.');
    } finally {
      setUploadingQr(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleQrDelete = async () => {
    setQrError(null);
    setQrSuccess(null);
    setUploadingQr(true);

    try {
      if (paySettings?.qr_code_storage_path) {
        await supabase.storage.from('payment-qr').remove([paySettings.qr_code_storage_path]);
      }

      const { data: updated, error: dbError } = await supabase
        .from('payment_settings')
        .update({
          qr_code_url: null,
          qr_code_storage_path: null,
          is_active: false,
          updated_at: new Date().toISOString(),
        })
        .eq('id', 1)
        .select()
        .single();

      if (dbError) throw dbError;
      setPaySettings(updated as PaymentSettings);
      setQrSuccess('QR code disabled and removed.');
      setTimeout(() => setQrSuccess(null), 4000);
    } catch (err) {
      setQrError(err instanceof Error ? err.message : 'Failed to delete QR code.');
    } finally {
      setUploadingQr(false);
    }
  };

  if (loading || !form) {
    return (
      <div className="text-center py-16">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-neutral-300 border-t-neutral-900 mx-auto" />
      </div>
    );
  }

  const inputClass = 'w-full px-3 py-2.5 border border-neutral-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-neutral-900';
  const labelClass = 'block text-sm font-medium text-neutral-700 mb-1';
  const sectionClass = 'bg-white border border-neutral-200 rounded-lg p-6 mb-6';
  const headingClass = 'text-lg font-semibold text-neutral-900 mb-4 flex items-center gap-2';

  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-serif font-bold text-neutral-900 mb-6">Settings</h1>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Store Information */}
        <div className={sectionClass}>
          <h2 className={headingClass}><Store size={18} /> Store Information</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className={labelClass}>Store Name</label>
              <input type="text" value={form.store_name} onChange={(e) => update('store_name', e.target.value)} className={inputClass} />
            </div>
          </div>
        </div>

        {/* Shipping */}
        <div className={sectionClass}>
          <h2 className={headingClass}><Truck size={18} /> Shipping</h2>
          <div className="space-y-4">
            <div className="p-3 bg-green-50 border border-green-200 rounded-lg text-sm text-green-700">
              SILORA offers free shipping on all orders, with no minimum purchase required.
            </div>
          </div>
        </div>

        {/* Payment Settings — QR Code Management */}
        <div className={sectionClass}>
          <h2 className={headingClass}><QrCode size={18} /> Payment Settings — UPI QR Code</h2>
          <div className="space-y-4">
            {qrError && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700 flex items-start gap-2">
                <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
                <span>{qrError}</span>
              </div>
            )}
            {qrSuccess && (
              <div className="p-3 bg-green-50 border border-green-200 rounded-lg text-sm text-green-700 flex items-start gap-2">
                <Check size={16} className="flex-shrink-0 mt-0.5" />
                <span>{qrSuccess}</span>
              </div>
            )}

            {/* Current QR preview */}
            {paySettings?.is_active && paySettings.qr_code_url ? (
              <div className="flex flex-col items-center gap-3 p-4 border border-neutral-200 rounded-lg">
                <div className="w-40 h-40 border-2 border-neutral-200 rounded-lg overflow-hidden bg-neutral-50 flex items-center justify-center">
                  <img src={paySettings.qr_code_url} alt="Active QR Code" className="w-full h-full object-contain" />
                </div>
                <div className="text-xs text-neutral-500 text-center">
                  <p>Status: <span className="font-medium text-green-700">Active</span></p>
                  <p>Last updated: {new Date(paySettings.updated_at).toLocaleString()}</p>
                </div>
              </div>
            ) : (
              <div className="p-4 border border-amber-200 rounded-lg bg-amber-50 text-sm text-amber-800">
                No QR code is currently active. Upload an image below to enable QR code payments.
              </div>
            )}

            {/* Upload new QR */}
            <div>
              <label className={labelClass}>Upload / Replace QR Code</label>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleQrUpload}
                disabled={uploadingQr}
                className="block w-full text-sm text-neutral-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-neutral-900 file:text-white hover:file:bg-neutral-800"
              />
              <p className="text-xs text-neutral-500 mt-1">Upload a UPI QR code image. This will replace any existing QR code and set it as active.</p>
            </div>

            {/* Delete / disable QR */}
            {paySettings?.qr_code_url && (
              <button
                type="button"
                onClick={handleQrDelete}
                disabled={uploadingQr}
                className="inline-flex items-center gap-2 px-4 py-2 border border-red-300 rounded-lg text-sm font-medium text-red-600 hover:bg-red-50 transition-colors disabled:opacity-50"
              >
                <Trash2 size={16} /> {paySettings.is_active ? 'Disable QR Code' : 'Delete QR Code'}
              </button>
            )}

            {/* Manual verification info */}
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-sm text-blue-700">
              <p className="font-medium">Manual Payment Verification</p>
              <p className="text-xs mt-1">Customers submit a transaction reference ID at checkout. Payments start as <strong>pending_verification</strong>. You verify them in the Orders panel — mark as <strong>paid</strong> or <strong>failed</strong>.</p>
            </div>
          </div>
        </div>

        {/* Homepage Content */}
        <div className={sectionClass}>
          <h2 className={headingClass}><Image size={18} /> Homepage Content</h2>
          <div className="space-y-4">
            <div>
              <label className={labelClass}>Hero Title</label>
              <input type="text" value={form.hero_title} onChange={(e) => update('hero_title', e.target.value)} className={inputClass} />
            </div>
            <div>
              <label className={labelClass}>Hero Subtitle</label>
              <input type="text" value={form.hero_subtitle} onChange={(e) => update('hero_subtitle', e.target.value)} className={inputClass} />
            </div>
            <div>
              <label className={labelClass}>Hero Image URL</label>
              <input type="text" value={form.hero_image} onChange={(e) => update('hero_image', e.target.value)} placeholder="https://..." className={inputClass} />
              <p className="text-xs text-neutral-500 mt-1">Leave empty to use the default hero design.</p>
            </div>
            <div className="flex items-center justify-between p-3 border border-neutral-200 rounded-lg">
              <div>
                <p className="text-sm font-medium text-neutral-900">Show Announcement Banner</p>
                <p className="text-xs text-neutral-500">Display a banner at the top of the homepage</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" checked={form.banner_visible} onChange={(e) => update('banner_visible', e.target.checked)} className="sr-only peer" />
                <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-neutral-900"></div>
              </label>
            </div>
            <div>
              <label className={labelClass}>Banner Text</label>
              <input type="text" value={form.banner_text} onChange={(e) => update('banner_text', e.target.value)} className={inputClass} />
            </div>
          </div>
        </div>

        {/* Contact Information */}
        <div className={sectionClass}>
          <h2 className={headingClass}><Mail size={18} /> Contact Information</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className={labelClass}>Contact Email</label>
              <input type="email" value={form.contact_email} onChange={(e) => update('contact_email', e.target.value)} className={inputClass} />
            </div>
            <div>
              <label className={labelClass}>Contact Phone</label>
              <input type="tel" value={form.contact_phone} onChange={(e) => update('contact_phone', e.target.value)} className={inputClass} />
            </div>
            <div className="sm:col-span-2">
              <label className={labelClass}>Contact Address</label>
              <textarea value={form.contact_address} onChange={(e) => update('contact_address', e.target.value)} rows={2} className={inputClass} />
            </div>
          </div>
        </div>

        {/* Store Policies */}
        <div className={sectionClass}>
          <h2 className={headingClass}><FileText size={18} /> Store Policies</h2>
          <div className="space-y-4">
            <div>
              <label className={labelClass}>Return Policy</label>
              <textarea value={form.return_policy} onChange={(e) => update('return_policy', e.target.value)} rows={4} className={inputClass} />
            </div>
            <div>
              <label className={labelClass}>Shipping Policy</label>
              <textarea value={form.shipping_policy} onChange={(e) => update('shipping_policy', e.target.value)} rows={4} className={inputClass} />
            </div>
            <div>
              <label className={labelClass}>Privacy Policy</label>
              <textarea value={form.privacy_policy} onChange={(e) => update('privacy_policy', e.target.value)} rows={4} className={inputClass} />
            </div>
            <div>
              <label className={labelClass}>Terms of Service</label>
              <textarea value={form.terms_of_service} onChange={(e) => update('terms_of_service', e.target.value)} rows={4} className={inputClass} />
            </div>
          </div>
        </div>

        {/* Phone OTP Info */}
        <div className={sectionClass}>
          <h2 className={headingClass}><MessageSquare size={18} /> Phone OTP Verification</h2>
          <div className="space-y-3 text-sm">
            <div className="flex items-start gap-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <Smartphone size={18} className="text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-blue-800">Mandatory at Signup & Checkout</p>
                <p className="text-xs text-blue-700 mt-1">
                  Every customer must verify their phone number with an SMS OTP during signup. Checkout is blocked until the phone is verified. Email is collected for contact but does not require verification.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-amber-50 border border-amber-200 rounded-lg">
              <AlertCircle size={18} className="text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-amber-800">SMS Provider Required</p>
                <p className="text-xs text-amber-700 mt-1">
                  Configure an SMS provider (Twilio, MessageBird, Vonage, or TextLocal) in your Supabase dashboard under <strong>Authentication &gt; Providers &gt; Phone</strong>. Phone OTP will not work without this.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Admin Account */}
        <div className={sectionClass}>
          <h2 className="text-lg font-semibold text-neutral-900 mb-4">Admin Account</h2>
          <div className="text-sm space-y-2">
            <div className="flex justify-between"><span className="text-neutral-600">Email</span><span className="font-medium text-neutral-900">{profile?.email}</span></div>
            <div className="flex justify-between"><span className="text-neutral-600">Role</span><span className="font-medium text-neutral-900 capitalize">{profile?.role}</span></div>
          </div>
        </div>

        {/* Save button */}
        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700 flex items-start gap-2">
            <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        <button
          type="submit"
          disabled={saving}
          className="px-6 py-3 bg-neutral-900 text-white rounded-lg text-sm font-medium hover:bg-neutral-800 transition-colors disabled:opacity-60 flex items-center gap-2"
        >
          {saving ? <Loader2 size={16} className="animate-spin" /> : saved ? <Check size={16} /> : <Save size={16} />}
          {saving ? 'Saving...' : saved ? 'Saved!' : 'Save all settings'}
        </button>
      </form>
    </div>
  );
}
