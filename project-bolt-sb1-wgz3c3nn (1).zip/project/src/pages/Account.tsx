import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { Loader2, AlertCircle, User, Package, LogOut, Check, Phone, ShieldCheck, ShieldAlert, RefreshCw, Clock, MessageSquare, Info } from 'lucide-react';
import { useSeo } from '@/lib/seo';

function toE164(raw: string): string | null {
  const digits = raw.replace(/[^\d]/g, '');
  if (!digits) return null;
  if (raw.startsWith('+')) return `+${digits}`;
  if (digits.length === 10) return `+91${digits}`;
  if (digits.length === 11 && digits.startsWith('0')) return `+91${digits.slice(1)}`;
  if (digits.length === 12 && digits.startsWith('91')) return `+${digits}`;
  if (digits.length > 10 && digits.length <= 15) return `+${digits}`;
  return null;
}

function maskPhone(e164: string): string {
  const digits = e164.replace(/[^\d]/g, '');
  if (digits.length < 4) return e164;
  const last4 = digits.slice(-4);
  const masked = '*'.repeat(Math.max(digits.length - 4, 0));
  return `+${masked}${last4}`;
}

function isSmsProviderError(msg: string): boolean {
  const m = msg.toLowerCase();
  return m.includes('sms provider') || m.includes('no sms') || m.includes('provider not')
    || m.includes('unable to get sms') || m.includes('sms_not_configured') || m.includes('phone provider');
}

export default function Account() {
  const { user, profile, signOut, refreshProfile } = useAuth();
  useSeo({
    title: 'My Account — SILORA',
    description: 'Manage your SILORA account details and verification status.',
    canonicalPath: '/account',
    noindex: true,
  });
  const [form, setForm] = useState({ full_name: '', phone: '' });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [phoneVerified, setPhoneVerified] = useState(false);
  const [sendingOtp, setSendingOtp] = useState(false);
  const [phoneOtpMode, setPhoneOtpMode] = useState(false);
  const [phoneOtp, setPhoneOtp] = useState('');
  const [phoneResendIn, setPhoneResendIn] = useState(0);
  const [phoneOtpError, setPhoneOtpError] = useState<string | null>(null);
  const [phoneOtpInfo, setPhoneOtpInfo] = useState<string | null>(null);
  const [verifyingPhone, setVerifyingPhone] = useState(false);
  const phoneRequestInProgress = useRef(false);

  useEffect(() => {
    if (phoneResendIn <= 0) return;
    const timer = setInterval(() => {
      setPhoneResendIn((s) => (s > 0 ? s - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [phoneResendIn]);

  useEffect(() => {
    if (profile) {
      setForm({
        full_name: profile.full_name ?? '',
        phone: profile.phone ?? '',
      });
    }
  }, [profile]);

  useEffect(() => {
    if (user) {
      setPhoneVerified(user.phone_confirmed_at != null);
    }
  }, [user]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaving(true);
    setSaved(false);

    const { error: updateError } = await supabase
      .from('profiles')
      .update({
        full_name: form.full_name,
      })
      .eq('id', user!.id);

    if (updateError) {
      setError(updateError.message);
      setSaving(false);
      return;
    }

    await refreshProfile();
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleSendPhoneOtp = async () => {
    setError(null);
    setPhoneOtpError(null);
    setPhoneOtpInfo(null);
    if (phoneRequestInProgress.current) return;
    phoneRequestInProgress.current = true;
    setSendingOtp(true);
    const e164 = toE164(form.phone);
    if (!e164) {
      setError('Enter a valid phone number (10 digits, or with country code).');
      phoneRequestInProgress.current = false;
      setSendingOtp(false);
      return;
    }
    const { error: phoneError } = await supabase.auth.updateUser({
      phone: e164,
    });
    phoneRequestInProgress.current = false;
    if (phoneError) {
      if (isSmsProviderError(phoneError.message)) {
        setPhoneOtpError('Phone OTP is not available yet. The store administrator needs to configure an SMS provider in Supabase.');
      } else {
        const m = phoneError.message.toLowerCase();
        if (m.includes('rate limit') || m.includes('429') || m.includes('too many')) {
          setPhoneOtpError('Too many OTP requests. Please wait a minute and try again.');
        } else {
          setPhoneOtpError(phoneError.message);
        }
      }
      setSendingOtp(false);
      return;
    }
    setPhoneOtpMode(true);
    setPhoneOtpInfo(`A verification code was sent to ${maskPhone(e164)}. Enter it below.`);
    setPhoneResendIn(60);
    setSendingOtp(false);
  };

  const handleVerifyPhoneOtp = async () => {
    setPhoneOtpError(null);
    if (!phoneOtp.trim()) {
      setPhoneOtpError('Enter the phone verification code.');
      return;
    }
    if (phoneRequestInProgress.current) return;
    phoneRequestInProgress.current = true;
    setVerifyingPhone(true);
    const e164 = toE164(form.phone)!;

    const { error: verifyError } = await supabase.auth.verifyOtp({
      phone: e164,
      token: phoneOtp.trim(),
      type: 'phone_change',
    });

    if (verifyError) {
      const m = verifyError.message.toLowerCase();
      if (m.includes('invalid') || m.includes('expired') || m.includes('token') || m.includes('code')) {
        setPhoneOtpError('Invalid or expired verification code.');
      } else {
        setPhoneOtpError(verifyError.message);
      }
      phoneRequestInProgress.current = false;
      setVerifyingPhone(false);
      return;
    }

    phoneRequestInProgress.current = false;

    const { data: userData } = await supabase.auth.getUser();
    if (userData.user) {
      await supabase.from('profiles').update({ phone: e164 }).eq('id', userData.user.id);
    }

    await refreshProfile();
    setPhoneVerified(true);
    setPhoneOtpMode(false);
    setPhoneOtp('');
    setPhoneOtpInfo(null);
    setPhoneResendIn(0);
    setVerifyingPhone(false);
  };

  const handleResendPhoneOtp = async () => {
    setPhoneOtpError(null);
    setPhoneOtpInfo(null);
    if (phoneResendIn > 0) return;
    if (phoneRequestInProgress.current) return;
    phoneRequestInProgress.current = true;
    setSendingOtp(true);
    const e164 = toE164(form.phone)!;
    const { error: phoneError } = await supabase.auth.updateUser({ phone: e164 });
    phoneRequestInProgress.current = false;
    if (phoneError) {
      if (isSmsProviderError(phoneError.message)) {
        setPhoneOtpError('Phone OTP is not available yet. The store administrator needs to configure an SMS provider in Supabase.');
      } else {
        setPhoneOtpError('Could not resend verification code. Please try again.');
      }
    } else {
      setPhoneResendIn(60);
      setPhoneOtpInfo(`A new verification code was sent to ${maskPhone(e164)}.`);
    }
    setSendingOtp(false);
  };

  if (!profile) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-neutral-300 border-t-neutral-900 mx-auto" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-serif font-bold text-neutral-900 mb-8">My Account</h1>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Sidebar */}
        <div className="md:col-span-1">
          <div className="bg-white border border-neutral-200 rounded-lg p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-neutral-100 rounded-full flex items-center justify-center">
                <User size={24} className="text-neutral-600" />
              </div>
              <div className="min-w-0">
                <p className="font-medium text-neutral-900 truncate">{profile.full_name || 'Customer'}</p>
                <p className="text-sm text-neutral-500 truncate">{profile.email}</p>
              </div>
            </div>

            {/* Verification badge */}
            <div className="space-y-2 mt-4">
              <div className={`flex items-center gap-2 text-xs ${phoneVerified ? 'text-green-700' : 'text-amber-700'}`}>
                {phoneVerified ? <ShieldCheck size={14} /> : <ShieldAlert size={14} />}
                {phoneVerified ? 'Phone verified' : 'Phone not verified'}
              </div>
            </div>

            <nav className="space-y-1 mt-6">
              <Link
                to="/orders"
                className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-neutral-700 hover:bg-neutral-50 rounded-lg transition-colors"
              >
                <Package size={18} /> My Orders
              </Link>
              <button
                onClick={signOut}
                className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors w-full"
              >
                <LogOut size={18} /> Sign out
              </button>
            </nav>
          </div>
        </div>

        {/* Profile form + verification */}
        <div className="md:col-span-2 space-y-6">
          {/* Verification status */}
          <div className="bg-white border border-neutral-200 rounded-lg p-6">
            <h2 className="text-lg font-semibold text-neutral-900 mb-4">Verification Status</h2>

            {/* Phone verification */}
            <div className={`flex items-start gap-3 p-3 rounded-lg border ${phoneVerified ? 'bg-green-50 border-green-200' : 'bg-amber-50 border-amber-200'}`}>
              {phoneVerified ? (
                <ShieldCheck size={20} className="text-green-600 flex-shrink-0 mt-0.5" />
              ) : (
                <ShieldAlert size={20} className="text-amber-600 flex-shrink-0 mt-0.5" />
              )}
              <div className="flex-1 w-full">
                <p className="text-sm font-medium text-neutral-900 flex items-center gap-1.5">
                  <Phone size={14} /> Phone
                </p>
                <p className={`text-xs mt-1 ${phoneVerified ? 'text-green-700' : 'text-amber-700'}`}>
                  {phoneVerified
                    ? 'Your phone number is verified.'
                    : 'Your phone number is not verified. Checkout is blocked until verified.'}
                </p>
                {!phoneVerified && !phoneOtpMode && (
                  <button
                    onClick={handleSendPhoneOtp}
                    disabled={sendingOtp || !form.phone}
                    className="mt-2 text-xs font-medium text-amber-900 underline inline-flex items-center gap-1"
                  >
                    {sendingOtp ? <Loader2 size={12} className="animate-spin" /> : <RefreshCw size={12} />}
                    Send phone OTP
                  </button>
                )}
                {!phoneVerified && phoneOtpMode && (
                  <div className="mt-3 space-y-3">
                    {phoneOtpInfo && (
                      <div className="p-2 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-700 flex items-start gap-1.5">
                        <Info size={12} className="flex-shrink-0 mt-0.5" />
                        <span>{phoneOtpInfo}</span>
                      </div>
                    )}
                    {phoneOtpError && (
                      <div className="p-2 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-start gap-1.5">
                        <AlertCircle size={12} className="flex-shrink-0 mt-0.5" />
                        <span>{phoneOtpError}</span>
                      </div>
                    )}
                    {phoneOtpError && phoneOtpError.includes('SMS provider') && (
                      <div className="p-2 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800 flex items-start gap-1.5">
                        <MessageSquare size={12} className="flex-shrink-0 mt-0.5" />
                        <span>The store owner needs to configure an SMS provider in Supabase (Twilio, MessageBird, Vonage, or TextLocal) under Authentication &gt; Providers &gt; Phone.</span>
                      </div>
                    )}
                    <div>
                      <input
                        type="text"
                        inputMode="numeric"
                        maxLength={6}
                        value={phoneOtp}
                        onChange={(e) => setPhoneOtp(e.target.value.replace(/[^\d]/g, ''))}
                        placeholder="6-digit code"
                        className="w-full px-3 py-2.5 border border-neutral-300 rounded-lg text-sm font-mono tracking-widest text-center focus:outline-none focus:ring-2 focus:ring-neutral-900"
                        autoFocus
                      />
                    </div>
                    <div className="flex items-center gap-3">
                      <button
                        onClick={handleVerifyPhoneOtp}
                        disabled={verifyingPhone || phoneOtp.length < 4}
                        className="px-4 py-2 bg-neutral-900 text-white rounded-lg text-xs font-medium hover:bg-neutral-800 transition-colors disabled:opacity-60 inline-flex items-center gap-1.5"
                      >
                        {verifyingPhone && <Loader2 size={12} className="animate-spin" />}
                        Verify phone
                      </button>
                      {phoneResendIn > 0 ? (
                        <span className="text-xs text-neutral-500 inline-flex items-center gap-1">
                          <Clock size={10} /> Resend in {phoneResendIn}s
                        </span>
                      ) : (
                        <button
                          onClick={handleResendPhoneOtp}
                          disabled={sendingOtp}
                          className="text-xs font-medium text-neutral-900 hover:underline inline-flex items-center gap-1 disabled:opacity-50"
                        >
                          <RefreshCw size={10} /> Resend code
                        </button>
                      )}
                      <button
                        onClick={() => { setPhoneOtpMode(false); setPhoneOtp(''); setPhoneOtpError(null); setPhoneOtpInfo(null); setPhoneResendIn(0); }}
                        className="text-xs text-neutral-500 hover:text-neutral-900"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Profile form */}
          <div className="bg-white border border-neutral-200 rounded-lg p-6">
            <h2 className="text-lg font-semibold text-neutral-900 mb-4">Profile Details</h2>

            <form onSubmit={handleSave} className="space-y-4">
              {error && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700 flex items-start gap-2">
                  <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">Email</label>
                <input
                  type="email"
                  value={profile.email}
                  disabled
                  className="w-full px-3 py-2.5 border border-neutral-200 rounded-lg text-sm bg-neutral-50 text-neutral-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">Full Name</label>
                <input
                  type="text"
                  value={form.full_name}
                  onChange={(e) => setForm({ ...form, full_name: e.target.value })}
                  className="w-full px-3 py-2.5 border border-neutral-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-neutral-900"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">Phone</label>
                <input
                  type="tel"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="w-full px-3 py-2.5 border border-neutral-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-neutral-900"
                  placeholder="Enter your phone number"
                />
                {phoneVerified && (
                  <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                    <Check size={12} /> Verified
                  </p>
                )}
              </div>

              <button
                type="submit"
                disabled={saving}
                className="px-6 py-2.5 bg-neutral-900 text-white rounded-lg font-medium hover:bg-neutral-800 transition-colors disabled:opacity-60 flex items-center gap-2"
              >
                {saving ? (
                  <Loader2 size={16} className="animate-spin" />
                ) : saved ? (
                  <Check size={16} />
                ) : null}
                {saving ? 'Saving...' : saved ? 'Saved!' : 'Save changes'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
