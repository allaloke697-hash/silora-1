import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { Loader2, AlertCircle, Mail, Lock, User, Phone, ShieldCheck, Check, RefreshCw, Info, MessageSquare, Clock } from 'lucide-react';
import { useSeo } from '@/lib/seo';

type SignupState = 'form' | 'phone_pending' | 'phone_verified' | 'completed';

function toE164(raw: string): string | null {
  const digits = raw.replace(/[^\d]/g, '');
  if (!digits) return null;
  if (raw.startsWith('+')) return `+${digits}`;
  if (digits.length === 10) return `+91${digits}`;
  if (digits.length === 11 && digits.startsWith('0')) return `+91${digits.slice(1)}`;
  if (digits.length === 12 && digits.startsWith('91')) return `+${digits}`;
  if (digits.length > 10 && digits.length <= 15) return `+${digits}`;
  return null;
}

function maskPhone(e164: string): string {
  const digits = e164.replace(/[^\d]/g, '');
  if (digits.length < 4) return e164;
  const last4 = digits.slice(-4);
  const masked = '*'.repeat(Math.max(digits.length - 4, 0));
  return `+${masked}${last4}`;
}

function isSmsProviderError(msg: string): boolean {
  const m = msg.toLowerCase();
  return m.includes('sms provider') || m.includes('no sms') || m.includes('provider not')
    || m.includes('unable to get sms') || m.includes('sms_not_configured') || m.includes('phone provider');
}

function isRateLimitError(msg: string): boolean {
  const m = msg.toLowerCase();
  return m.includes('rate limit') || m.includes('429') || m.includes('too many');
}

export default function Signup() {
  const navigate = useNavigate();
  const { refreshProfile } = useAuth();
  useSeo({
    title: 'Create Account — SILORA',
    description: 'Sign up for a SILORA account to shop quality products with free shipping.',
    canonicalPath: '/signup',
    noindex: true,
  });
  const [form, setForm] = useState({ full_name: '', email: '', phone: '', password: '', confirm: '' });
  const [state, setState] = useState<SignupState>('form');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  const [phoneOtp, setPhoneOtp] = useState('');
  const [resendIn, setResendIn] = useState(0);
  const requestInProgress = useRef(false);

  useEffect(() => {
    if (resendIn <= 0) return;
    const timer = setInterval(() => {
      setResendIn((s) => (s > 0 ? s - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [resendIn]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const validateForm = (): string | null => {
    if (!form.full_name.trim()) return 'Full name is required';
    if (!form.email.trim()) return 'Email is required';
    if (!/\S+@\S+\.\S+/.test(form.email.trim())) return 'Enter a valid email';
    if (!form.phone.trim()) return 'Phone number is required';
    if (!toE164(form.phone)) return 'Enter a valid mobile number (10 digits, or with country code)';
    if (form.password.length < 6) return 'Password must be at least 6 characters';
    if (form.password !== form.confirm) return 'Passwords do not match';
    return null;
  };

  const sendPhoneOtp = async (e164: string): Promise<{ success: boolean; error?: string }> => {
    const { error: phoneError } = await supabase.auth.signInWithOtp({
      phone: e164,
      options: {
        data: { full_name: form.full_name.trim(), email: form.email.trim() },
      },
    });
    if (phoneError) {
      if (isSmsProviderError(phoneError.message)) {
        return { success: false, error: 'Phone OTP is not available yet. The store administrator needs to configure an SMS provider in Supabase.' };
      }
      if (isRateLimitError(phoneError.message)) {
        return { success: false, error: 'Too many OTP requests. Please wait a minute and try again.' };
      }
      return { success: false, error: phoneError.message };
    }
    return { success: true };
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setInfo(null);

    const validationError = validateForm();
    if (validationError) {
      setError(validationError);
      return;
    }

    if (requestInProgress.current) return;
    requestInProgress.current = true;
    setLoading(true);

    const e164 = toE164(form.phone)!;

    const result = await sendPhoneOtp(e164);

    requestInProgress.current = false;

    if (!result.success) {
      setError(result.error ?? 'Phone verification could not be started. Please try again.');
      setLoading(false);
      return;
    }

    setInfo(`A 6-digit verification code was sent to ${maskPhone(e164)}. Enter it below to confirm your phone number.`);
    setState('phone_pending');
    setResendIn(60);
    setLoading(false);
  };

  const handleVerifyPhoneOtp = async () => {
    setError(null);
    if (!phoneOtp.trim()) {
      setError('Enter the phone verification code.');
      return;
    }

    if (requestInProgress.current) return;
    requestInProgress.current = true;
    setLoading(true);
    const e164 = toE164(form.phone)!;

    const { data: verifyData, error: verifyError } = await supabase.auth.verifyOtp({
      phone: e164,
      token: phoneOtp.trim(),
      type: 'sms',
    });

    if (verifyError) {
      const m = verifyError.message.toLowerCase();
      if (m.includes('invalid') || m.includes('expired') || m.includes('token') || m.includes('code')) {
        setError('Invalid or expired verification code.');
      } else {
        setError(verifyError.message);
      }
      requestInProgress.current = false;
      setLoading(false);
      return;
    }

    requestInProgress.current = false;

    // Set password on the now-authenticated user.
    if (verifyData.user) {
      const { error: passwordError } = await supabase.auth.updateUser({
        password: form.password,
        data: { full_name: form.full_name.trim(), email: form.email.trim() },
      });

      if (passwordError) {
        setError(passwordError.message);
        setLoading(false);
        return;
      }

      // Persist phone to profile.
      await supabase.from('profiles').update({ phone: e164 }).eq('id', verifyData.user.id);
    }

    setState('phone_verified');
    setPhoneOtp('');
    setLoading(false);

    setTimeout(() => completeSignup(), 600);
  };

  const completeSignup = async () => {
    setLoading(true);
    await refreshProfile();
    setState('completed');
    setLoading(false);
  };

  const handleResendPhone = async () => {
    setError(null);
    setInfo(null);
    if (resendIn > 0) return;
    if (requestInProgress.current) return;
    requestInProgress.current = true;
    setLoading(true);
    const e164 = toE164(form.phone)!;
    const result = await sendPhoneOtp(e164);
    requestInProgress.current = false;
    if (!result.success) {
      setError(result.error ?? 'Phone verification could not be started. Please try again.');
    } else {
      setResendIn(60);
      setInfo(`A new verification code was sent to ${maskPhone(e164)}.`);
    }
    setLoading(false);
  };

  // ---- COMPLETED screen ----
  if (state === 'completed') {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-4 py-12">
        <div className="max-w-md w-full">
          <div className="text-center mb-8">
            <ShieldCheck size={64} className="text-green-600 mx-auto mb-4" />
            <h1 className="text-3xl font-serif font-bold text-neutral-900">Account created successfully</h1>
            <p className="text-neutral-600 mt-2">Your phone number is verified. You can now start shopping.</p>
          </div>
          <button
            onClick={() => navigate('/account', { replace: true })}
            className="w-full px-6 py-3 bg-neutral-900 text-white rounded-lg font-medium hover:bg-neutral-800 transition-colors"
          >
            Continue to your account
          </button>
        </div>
      </div>
    );
  }

  // ---- PHONE VERIFIED (brief transition) ----
  if (state === 'phone_verified') {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-4 py-12">
        <div className="max-w-md w-full text-center">
          <Check size={56} className="text-green-600 mx-auto mb-4" />
          <h1 className="text-2xl font-serif font-bold text-neutral-900">Phone verified</h1>
          <p className="text-sm text-neutral-600 mt-2">Completing your account...</p>
          <Loader2 size={24} className="animate-spin text-neutral-400 mx-auto mt-4" />
        </div>
      </div>
    );
  }

  // ---- Phone OTP verification screen ----
  if (state === 'phone_pending') {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-4 py-12">
        <div className="max-w-md w-full">
          <div className="text-center mb-8">
            <Phone size={56} className="text-neutral-900 mx-auto mb-4" />
            <h1 className="text-2xl font-serif font-bold text-neutral-900">Verify your phone</h1>
            <p className="text-sm text-neutral-600 mt-2">
              Enter the 6-digit code sent to {toE164(form.phone) ?? ''}.
            </p>
          </div>

          <div className="bg-white border border-neutral-200 rounded-lg p-6 space-y-4">
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700 flex items-start gap-2">
                <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            {error && error.includes('SMS provider') && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-800 flex items-start gap-2">
                <MessageSquare size={16} className="flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium">SMS provider not configured</p>
                  <p className="text-xs mt-1">The store administrator needs to configure an SMS provider in Supabase (Twilio, MessageBird, Vonage, or TextLocal) under Authentication &gt; Providers &gt; Phone.</p>
                </div>
              </div>
            )}

            {info && (
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-sm text-blue-700 flex items-start gap-2">
                <Info size={16} className="flex-shrink-0 mt-0.5" />
                <span>{info}</span>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">
                Phone verification code (OTP)
              </label>
              <input
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={phoneOtp}
                onChange={(e) => setPhoneOtp(e.target.value.replace(/[^\d]/g, ''))}
                placeholder="6-digit code"
                className="w-full px-3 py-3 border border-neutral-300 rounded-lg text-sm font-mono tracking-widest text-center focus:outline-none focus:ring-2 focus:ring-neutral-900"
                autoFocus
              />
            </div>

            <button
              onClick={handleVerifyPhoneOtp}
              disabled={loading || phoneOtp.length < 4}
              className="w-full px-6 py-3 bg-neutral-900 text-white rounded-lg font-medium hover:bg-neutral-800 transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
            >
              {loading && <Loader2 size={18} className="animate-spin" />}
              Verify phone
            </button>

            <div className="text-center text-sm">
              {resendIn > 0 ? (
                <span className="text-neutral-500 inline-flex items-center gap-1">
                  <Clock size={12} /> Resend code in {resendIn}s
                </span>
              ) : (
                <button
                  onClick={handleResendPhone}
                  disabled={loading}
                  className="text-neutral-900 font-medium hover:underline inline-flex items-center gap-1 disabled:opacity-50"
                >
                  <RefreshCw size={12} /> Resend code
                </button>
              )}
            </div>
          </div>

          {/* Progress indicator */}
          <div className="flex items-center justify-center gap-2 mt-6 text-xs text-neutral-500">
            <span className="font-bold text-neutral-900">1. Phone</span>
            <Check size={12} className="text-neutral-300" />
            <span>2. Done</span>
          </div>
        </div>
      </div>
    );
  }

  // ---- Initial form ----
  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-12">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-serif font-bold text-neutral-900">Create account</h1>
          <p className="text-neutral-600 mt-2">Join SILORA and start shopping</p>
        </div>

        <form onSubmit={handleSignUp} className="bg-white border border-neutral-200 rounded-lg p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700 flex items-start gap-2">
              <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {info && (
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-sm text-blue-700 flex items-start gap-2">
              <Info size={16} className="flex-shrink-0 mt-0.5" />
              <span>{info}</span>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Full Name</label>
            <div className="relative">
              <User size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
              <input
                type="text"
                name="full_name"
                value={form.full_name}
                onChange={handleChange}
                required
                className="w-full pl-10 pr-4 py-2.5 border border-neutral-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-neutral-900"
                placeholder="Jane Doe"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Email</label>
            <div className="relative">
              <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
              <input
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                required
                className="w-full pl-10 pr-4 py-2.5 border border-neutral-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-neutral-900"
                placeholder="you@example.com"
              />
            </div>
            <p className="text-xs text-neutral-500 mt-1">Used for order updates and account recovery.</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Mobile Number</label>
            <div className="relative">
              <Phone size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
              <input
                type="tel"
                name="phone"
                value={form.phone}
                onChange={handleChange}
                required
                className="w-full pl-10 pr-4 py-2.5 border border-neutral-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-neutral-900"
                placeholder="10-digit mobile number"
              />
            </div>
            <p className="text-xs text-neutral-500 mt-1">You'll receive an OTP to verify this number.</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Password</label>
            <div className="relative">
              <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
              <input
                type="password"
                name="password"
                value={form.password}
                onChange={handleChange}
                required
                className="w-full pl-10 pr-4 py-2.5 border border-neutral-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-neutral-900"
                placeholder="Min. 6 characters"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Confirm Password</label>
            <div className="relative">
              <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
              <input
                type="password"
                name="confirm"
                value={form.confirm}
                onChange={handleChange}
                required
                className="w-full pl-10 pr-4 py-2.5 border border-neutral-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-neutral-900"
                placeholder="Re-enter password"
              />
            </div>
          </div>

          <div className="text-xs text-neutral-500 bg-neutral-50 border border-neutral-200 rounded-lg p-3">
            After submitting, you'll verify your phone number with a 6-digit one-time code sent via SMS.
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full px-6 py-3 bg-neutral-900 text-white rounded-lg font-medium hover:bg-neutral-800 transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {loading && <Loader2 size={18} className="animate-spin" />}
            Create account
          </button>

          <p className="text-center text-sm text-neutral-600">
            Already have an account?{' '}
            <Link to="/login" className="font-medium text-neutral-900 hover:underline">
              Sign in
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
}
