import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { Loader2, AlertCircle, Mail, Lock, Phone, RefreshCw, MessageSquare, Clock } from 'lucide-react';
import { useSeo } from '@/lib/seo';

function toE164(raw: string): string | null {
  const digits = raw.replace(/[^\d]/g, '');
  if (!digits) return null;
  if (raw.startsWith('+')) return `+${digits}`;
  if (digits.length === 10) return `+91${digits}`;
  if (digits.length === 11 && digits.startsWith('0')) return `+91${digits.slice(1)}`;
  if (digits.length === 12 && digits.startsWith('91')) return `+${digits}`;
  if (digits.length > 10 && digits.length <= 15) return `+${digits}`;
  return null;
}

function maskPhone(e164: string): string {
  const digits = e164.replace(/[^\d]/g, '');
  if (digits.length < 4) return e164;
  const last4 = digits.slice(-4);
  const masked = '*'.repeat(Math.max(digits.length - 4, 0));
  return `+${masked}${last4}`;
}

function isSmsProviderError(msg: string): boolean {
  const m = msg.toLowerCase();
  return m.includes('sms provider') || m.includes('no sms') || m.includes('provider not')
    || m.includes('unable to get sms') || m.includes('sms_not_configured') || m.includes('phone provider');
}

function isRateLimitError(msg: string): boolean {
  const m = msg.toLowerCase();
  return m.includes('rate limit') || m.includes('429') || m.includes('too many');
}

type PhoneLoginState = 'input' | 'otp_pending';

export default function Login() {
  const { user } = useAuth();
  useSeo({
    title: 'Sign In — SILORA',
    description: 'Sign in to your SILORA account to place orders and track deliveries.',
    canonicalPath: '/login',
    noindex: true,
  });
  const navigate = useNavigate();
  const location = useLocation();

  const [mode, setMode] = useState<'email' | 'phone'>('email');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Phone login state
  const [phoneInput, setPhoneInput] = useState('');
  const [phoneLoginState, setPhoneLoginState] = useState<PhoneLoginState>('input');
  const [phoneOtp, setPhoneOtp] = useState('');
  const [resendIn, setResendIn] = useState(0);
  const requestInProgress = useRef(false);

  const from = (location.state as { from?: string })?.from ?? '/account';

  useEffect(() => {
    if (resendIn <= 0) return;
    const timer = setInterval(() => {
      setResendIn((s) => (s > 0 ? s - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [resendIn]);

  // Redirect if already logged in
  if (user) {
    navigate(from, { replace: true });
  }

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });

    if (signInError) {
      setError(signInError.message);
      setLoading(false);
      return;
    }

    navigate(from, { replace: true });
  };

  const sendPhoneLoginOtp = async (): Promise<{ success: boolean; error?: string }> => {
    const e164 = toE164(phoneInput);
    if (!e164) {
      return { success: false, error: 'Enter a valid mobile number (10 digits, or with country code).' };
    }

    // shouldCreateUser: false — do NOT create a new account for unknown phone numbers.
    const { error: otpError } = await supabase.auth.signInWithOtp({
      phone: e164,
      options: { shouldCreateUser: false },
    });

    if (otpError) {
      if (isSmsProviderError(otpError.message)) {
        return { success: false, error: 'Phone OTP is currently unavailable. Please configure an SMS provider in Supabase.' };
      }
      if (isRateLimitError(otpError.message)) {
        return { success: false, error: 'Too many OTP requests. Please wait a minute and try again.' };
      }
      return { success: false, error: otpError.message };
    }
    return { success: true };
  };

  const handleSendPhoneOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (requestInProgress.current) return;
    requestInProgress.current = true;
    setLoading(true);

    const result = await sendPhoneLoginOtp();

    requestInProgress.current = false;

    if (!result.success) {
      setError(result.error ?? 'Could not send OTP. Please try again.');
      setLoading(false);
      return;
    }

    setPhoneLoginState('otp_pending');
    setResendIn(60);
    setLoading(false);
  };

  const handleVerifyPhoneLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!phoneOtp.trim()) {
      setError('Enter the verification code sent to your phone.');
      return;
    }

    if (requestInProgress.current) return;
    requestInProgress.current = true;
    setLoading(true);

    const e164 = toE164(phoneInput)!;

    const { error: verifyError } = await supabase.auth.verifyOtp({
      phone: e164,
      token: phoneOtp.trim(),
      type: 'sms',
    });

    if (verifyError) {
      const m = verifyError.message.toLowerCase();
      if (m.includes('invalid') || m.includes('expired') || m.includes('token') || m.includes('code')) {
        setError('Invalid or expired verification code.');
      } else {
        setError(verifyError.message);
      }
      requestInProgress.current = false;
      setLoading(false);
      return;
    }

    requestInProgress.current = false;
    navigate(from, { replace: true });
  };

  const handleResendPhoneOtp = async () => {
    setError(null);
    if (resendIn > 0) return;
    if (requestInProgress.current) return;
    requestInProgress.current = true;
    setLoading(true);

    const result = await sendPhoneLoginOtp();

    requestInProgress.current = false;

    if (!result.success) {
      setError(result.error ?? 'Could not resend OTP. Please try again.');
    } else {
      setResendIn(60);
    }
    setLoading(false);
  };

  const resetPhoneLogin = () => {
    setPhoneLoginState('input');
    setPhoneOtp('');
    setResendIn(0);
    setError(null);
  };

  // ---- Phone OTP verification screen ----
  if (mode === 'phone' && phoneLoginState === 'otp_pending') {
    const e164 = toE164(phoneInput) ?? '';
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-4 py-12">
        <div className="max-w-md w-full">
          <div className="text-center mb-8">
            <Phone size={56} className="text-neutral-900 mx-auto mb-4" />
            <h1 className="text-2xl font-serif font-bold text-neutral-900">Verify your phone</h1>
            <p className="text-sm text-neutral-600 mt-2">
              Enter the 6-digit code sent to {maskPhone(e164)}.
            </p>
          </div>

          <form onSubmit={handleVerifyPhoneLogin} className="bg-white border border-neutral-200 rounded-lg p-6 space-y-4">
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700 flex items-start gap-2">
                <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">
                Phone verification code (OTP)
              </label>
              <input
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={phoneOtp}
                onChange={(e) => setPhoneOtp(e.target.value.replace(/[^\d]/g, ''))}
                placeholder="6-digit code"
                className="w-full px-3 py-3 border border-neutral-300 rounded-lg text-sm font-mono tracking-widest text-center focus:outline-none focus:ring-2 focus:ring-neutral-900"
                autoFocus
              />
            </div>

            <button
              type="submit"
              disabled={loading || phoneOtp.length < 4}
              className="w-full px-6 py-3 bg-neutral-900 text-white rounded-lg font-medium hover:bg-neutral-800 transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
            >
              {loading && <Loader2 size={18} className="animate-spin" />}
              Verify phone
            </button>

            <div className="text-center text-sm">
              {resendIn > 0 ? (
                <span className="text-neutral-500 inline-flex items-center gap-1">
                  <Clock size={12} /> Resend OTP in {resendIn}s
                </span>
              ) : (
                <button
                  type="button"
                  onClick={handleResendPhoneOtp}
                  disabled={loading}
                  className="text-neutral-900 font-medium hover:underline inline-flex items-center gap-1 disabled:opacity-50"
                >
                  <RefreshCw size={12} /> Resend OTP
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={resetPhoneLogin}
              className="w-full text-center text-sm text-neutral-500 hover:text-neutral-900"
            >
              Use a different phone number
            </button>
          </form>
        </div>
      </div>
    );
  }

  // ---- Login forms ----
  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-12">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-serif font-bold text-neutral-900">Welcome back</h1>
          <p className="text-neutral-600 mt-2">Sign in to your SILORA account</p>
        </div>

        {/* Mode toggle */}
        <div className="flex border border-neutral-200 rounded-lg overflow-hidden mb-6">
          <button
            onClick={() => { setMode('email'); setError(null); }}
            className={`flex-1 px-4 py-2.5 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${
              mode === 'email' ? 'bg-neutral-900 text-white' : 'bg-white text-neutral-600 hover:bg-neutral-50'
            }`}
          >
            <Mail size={16} /> Email
          </button>
          <button
            onClick={() => { setMode('phone'); setError(null); setPhoneLoginState('input'); }}
            className={`flex-1 px-4 py-2.5 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${
              mode === 'phone' ? 'bg-neutral-900 text-white' : 'bg-white text-neutral-600 hover:bg-neutral-50'
            }`}
          >
            <Phone size={16} /> Phone
          </button>
        </div>

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700 flex items-start gap-2 mb-4">
            <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {error && isSmsProviderError(error) && (
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-800 flex items-start gap-2 mb-4">
            <MessageSquare size={16} className="flex-shrink-0 mt-0.5" />
            <span>The store administrator needs to configure an SMS provider in Supabase under Authentication &gt; Providers &gt; Phone.</span>
          </div>
        )}

        {mode === 'email' ? (
          <form onSubmit={handleEmailLogin} className="bg-white border border-neutral-200 rounded-lg p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Email</label>
              <div className="relative">
                <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full pl-10 pr-4 py-2.5 border border-neutral-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-neutral-900"
                  placeholder="you@example.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Password</label>
              <div className="relative">
                <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full pl-10 pr-4 py-2.5 border border-neutral-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-neutral-900"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <div className="text-right">
              <Link to="/forgot-password" className="text-sm text-neutral-600 hover:text-neutral-900">
                Forgot password?
              </Link>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full px-6 py-3 bg-neutral-900 text-white rounded-lg font-medium hover:bg-neutral-800 transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
            >
              {loading && <Loader2 size={18} className="animate-spin" />}
              Sign in
            </button>
          </form>
        ) : (
          <form onSubmit={handleSendPhoneOtp} className="bg-white border border-neutral-200 rounded-lg p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Mobile Number</label>
              <div className="relative">
                <Phone size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                <input
                  type="tel"
                  value={phoneInput}
                  onChange={(e) => setPhoneInput(e.target.value)}
                  required
                  className="w-full pl-10 pr-4 py-2.5 border border-neutral-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-neutral-900"
                  placeholder="10-digit mobile number"
                />
              </div>
              <p className="text-xs text-neutral-500 mt-1">You'll receive an OTP via SMS to verify your number.</p>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full px-6 py-3 bg-neutral-900 text-white rounded-lg font-medium hover:bg-neutral-800 transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
            >
              {loading && <Loader2 size={18} className="animate-spin" />}
              Send OTP
            </button>
          </form>
        )}

        <p className="text-center text-sm text-neutral-600 mt-6">
          Don't have an account?{' '}
          <Link to="/signup" className="font-medium text-neutral-900 hover:underline">
            Sign up
          </Link>
        </p>
      </div>
    </div>
  );
}
