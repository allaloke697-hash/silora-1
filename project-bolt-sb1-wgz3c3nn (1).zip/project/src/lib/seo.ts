import { useEffect } from 'react';

interface SeoOptions {
  title: string;
  description: string;
  canonicalPath?: string;
  ogType?: string;
  ogImage?: string;
  ogTitle?: string;
  ogDescription?: string;
  twitterCard?: 'summary' | 'summary_large_image';
  noindex?: boolean;
  jsonLd?: object | object[];
}

const SITE_URL = 'https://thesilora.com';
const DEFAULT_IMAGE = `${SITE_URL}/og-image.png`;

function setMeta(attr: 'name' | 'property', key: string, content: string) {
  let el = document.head.querySelector(`meta[${attr}="${key}"]`) as HTMLMetaElement | null;
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.head.querySelector(`link[rel="${rel}"]`) as HTMLLinkElement | null;
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}

function setJsonLd(id: string, data: object | object[]) {
  let el = document.getElementById(id) as HTMLScriptElement | null;
  const content = JSON.stringify(data);
  if (!el) {
    el = document.createElement('script');
    el.id = id;
    el.setAttribute('type', 'application/ld+json');
    document.head.appendChild(el);
  }
  el.textContent = content;
}

function removeJsonLd(id: string) {
  const el = document.getElementById(id);
  if (el) el.remove();
}

export function useSeo(opts: SeoOptions) {
  useEffect(() => {
    const canonicalUrl = opts.canonicalPath ? `${SITE_URL}${opts.canonicalPath}` : SITE_URL;
    const ogImage = opts.ogImage || DEFAULT_IMAGE;

    document.title = opts.title;

    setMeta('name', 'description', opts.description);
    setLink('canonical', canonicalUrl);

    // Robots
    if (opts.noindex) {
      setMeta('name', 'robots', 'noindex, nofollow');
    } else {
      const existing = document.head.querySelector('meta[name="robots"]');
      if (existing) existing.remove();
    }

    // Open Graph
    setMeta('property', 'og:title', opts.ogTitle || opts.title);
    setMeta('property', 'og:description', opts.ogDescription || opts.description);
    setMeta('property', 'og:type', opts.ogType || 'website');
    setMeta('property', 'og:url', canonicalUrl);
    setMeta('property', 'og:image', ogImage);
    setMeta('property', 'og:site_name', 'SILORA');

    // Twitter
    setMeta('name', 'twitter:card', opts.twitterCard || 'summary_large_image');
    setMeta('name', 'twitter:title', opts.ogTitle || opts.title);
    setMeta('name', 'twitter:description', opts.ogDescription || opts.description);
    setMeta('name', 'twitter:image', ogImage);

    // JSON-LD
    if (opts.jsonLd) {
      const data = Array.isArray(opts.jsonLd) ? opts.jsonLd : [opts.jsonLd];
      setJsonLd('seo-jsonld', data);
    } else {
      removeJsonLd('seo-jsonld');
    }

    return () => {
      removeJsonLd('seo-jsonld');
    };
  }, [
    opts.title,
    opts.description,
    opts.canonicalPath,
    opts.ogType,
    opts.ogImage,
    opts.ogTitle,
    opts.ogDescription,
    opts.twitterCard,
    opts.noindex,
    opts.jsonLd,
  ]);
}

export { SITE_URL };
