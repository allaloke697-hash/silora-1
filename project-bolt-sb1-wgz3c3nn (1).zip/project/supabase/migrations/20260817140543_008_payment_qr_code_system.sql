/*
# Payment QR Code System

## Purpose
Replace the UPI ID text display in customer checkout with a QR code image.
Admins can upload, preview, replace, and delete/disable QR codes.
Only one QR code is active at a time.

## New Tables
- `payment_settings`
  - `id` (int, primary key, default 1 — singleton row)
  - `qr_code_url` (text, nullable — public URL of the QR code image in storage)
  - `qr_code_storage_path` (text, nullable — storage path for deletion)
  - `is_active` (boolean, default false — whether a QR code is currently active)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)
  - `updated_by` (uuid, nullable — admin who last updated)

## Storage
- Creates a `payment-qr` storage bucket (public read, admin-only write)
- Storage policies:
  - Public read: anyone can view QR code images
  - Admin-only write: only authenticated users with admin role can upload/delete

## Security (RLS)
- `payment_settings` table:
  - SELECT: any authenticated user can read (customers need to see active QR)
  - INSERT/UPDATE/DELETE: only admin users (checked via profiles table role column)
- Uses a SECURITY DEFINER helper function `is_admin()` to check role safely

## Important Notes
1. This migration does NOT modify the existing `store_settings` table or its `upi_id` column — that column remains for backward compatibility but is no longer displayed in checkout.
2. Existing products, orders, customers, and admin functions are untouched.
3. The singleton row (id=1) is created with `is_active = false` so checkout will show a "no QR code" state until an admin uploads one.
*/

-- ============================================================
-- 1. Helper function: is_admin()
-- ============================================================
-- Checks if the current authenticated user has role = 'admin' in profiles.
-- SECURITY DEFINER so it can bypass RLS on profiles to read the role.

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  );
$$;

-- ============================================================
-- 2. payment_settings table
-- ============================================================

CREATE TABLE IF NOT EXISTS public.payment_settings (
  id integer PRIMARY KEY DEFAULT 1,
  qr_code_url text,
  qr_code_storage_path text,
  is_active boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  CONSTRAINT payment_settings_singleton CHECK (id = 1)
);

ALTER TABLE public.payment_settings ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if any (idempotent)
DROP POLICY IF EXISTS "read_payment_settings" ON public.payment_settings;
DROP POLICY IF EXISTS "insert_payment_settings" ON public.payment_settings;
DROP POLICY IF EXISTS "update_payment_settings" ON public.payment_settings;
DROP POLICY IF EXISTS "delete_payment_settings" ON public.payment_settings;

-- Anyone authenticated (including customers) can read the active QR config
CREATE POLICY "read_payment_settings"
ON public.payment_settings FOR SELECT
TO authenticated
USING (true);

-- Only admins can insert
CREATE POLICY "insert_payment_settings"
ON public.payment_settings FOR INSERT
TO authenticated
WITH CHECK (public.is_admin());

-- Only admins can update
CREATE POLICY "update_payment_settings"
ON public.payment_settings FOR UPDATE
TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- Only admins can delete
CREATE POLICY "delete_payment_settings"
ON public.payment_settings FOR DELETE
TO authenticated
USING (public.is_admin());

-- Insert the singleton row if it doesn't exist
INSERT INTO public.payment_settings (id, is_active)
VALUES (1, false)
ON CONFLICT (id) DO NOTHING;

-- ============================================================
-- 3. Storage bucket for QR codes
-- ============================================================

INSERT INTO storage.buckets (id, name, public)
VALUES ('payment-qr', 'payment-qr', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies
-- Public read: anyone can view QR images
DROP POLICY IF EXISTS "public_read_payment_qr" ON storage.objects;
CREATE POLICY "public_read_payment_qr"
ON storage.objects FOR SELECT
TO anon, authenticated
USING (bucket_id = 'payment-qr');

-- Admin-only upload
DROP POLICY IF EXISTS "admin_upload_payment_qr" ON storage.objects;
CREATE POLICY "admin_upload_payment_qr"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'payment-qr' AND public.is_admin());

-- Admin-only update
DROP POLICY IF EXISTS "admin_update_payment_qr" ON storage.objects;
CREATE POLICY "admin_update_payment_qr"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'payment-qr' AND public.is_admin())
WITH CHECK (bucket_id = 'payment-qr' AND public.is_admin());

-- Admin-only delete
DROP POLICY IF EXISTS "admin_delete_payment_qr" ON storage.objects;
CREATE POLICY "admin_delete_payment_qr"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'payment-qr' AND public.is_admin());
