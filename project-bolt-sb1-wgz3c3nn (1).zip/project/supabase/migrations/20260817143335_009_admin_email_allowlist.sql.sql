/*
# Admin Email Allowlist

## What changes
1. Create `admin_allowlist` table to store authorized admin email addresses.
2. Insert karthikeyareddymule@gmail.com (and preserve existing admin allaloke697@gmail.com).
3. Update `handle_new_user` trigger to automatically set role='admin' when a new user's email is in the allowlist.
4. RLS: only admins can read/manage the allowlist. No service-role keys in frontend.

## Security
- `admin_allowlist` RLS: SELECT/INSERT/UPDATE/DELETE restricted to authenticated admins.
- The trigger function is SECURITY DEFINER so it can read the allowlist regardless of caller permissions.
- No frontend code changes needed — the profile role is set automatically at signup.
*/

-- 1. Create admin_allowlist table
CREATE TABLE IF NOT EXISTS public.admin_allowlist (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.admin_allowlist ENABLE ROW LEVEL SECURITY;

-- RLS: only admins can read/manage the allowlist
DROP POLICY IF EXISTS "admin_allowlist_select_admin" ON public.admin_allowlist;
CREATE POLICY "admin_allowlist_select_admin" ON public.admin_allowlist
  FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "admin_allowlist_insert_admin" ON public.admin_allowlist;
CREATE POLICY "admin_allowlist_insert_admin" ON public.admin_allowlist
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "admin_allowlist_update_admin" ON public.admin_allowlist;
CREATE POLICY "admin_allowlist_update_admin" ON public.admin_allowlist
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "admin_allowlist_delete_admin" ON public.admin_allowlist;
CREATE POLICY "admin_allowlist_delete_admin" ON public.admin_allowlist
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- 2. Insert admin emails (idempotent)
INSERT INTO public.admin_allowlist (email) VALUES
  ('karthikeyareddymule@gmail.com'),
  ('allaloke697@gmail.com')
ON CONFLICT (email) DO NOTHING;

-- 3. Update handle_new_user to check allowlist and auto-assign admin role
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  is_admin boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1 FROM public.admin_allowlist WHERE email = LOWER(NEW.email)
  ) INTO is_admin;

  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    CASE WHEN is_admin THEN 'admin' ELSE 'customer' END
  )
  ON CONFLICT (id) DO UPDATE
  SET role = CASE WHEN is_admin THEN 'admin' ELSE public.profiles.role END,
      email = EXCLUDED.email,
      full_name = CASE
        WHEN public.profiles.full_name IS NULL OR public.profiles.full_name = ''
        THEN EXCLUDED.full_name
        ELSE public.profiles.full_name
      END;

  RETURN NEW;
END;
$$;

-- 4. Backfill: ensure existing allowlisted users have admin role
UPDATE public.profiles
SET role = 'admin', updated_at = now()
WHERE LOWER(email) IN (SELECT LOWER(email) FROM public.admin_allowlist)
  AND role != 'admin';
