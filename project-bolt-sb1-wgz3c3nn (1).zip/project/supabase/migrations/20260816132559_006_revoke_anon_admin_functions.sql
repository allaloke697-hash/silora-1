/*
# Fix: Revoke anon execute on admin functions

## What changes
- Revoke EXECUTE on `admin_delete_customer` and `admin_cleanup_orphaned_profiles` from the `anon` role.
- These are admin-only SECURITY DEFINER functions and must not be callable by unauthenticated users.

## Security
- Only `authenticated` role can call these functions (already granted in migration 005).
- The functions internally verify admin role, but defense in depth means anon should not even reach them.
*/

REVOKE EXECUTE ON FUNCTION public.admin_delete_customer(uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.admin_cleanup_orphaned_profiles() FROM anon;
