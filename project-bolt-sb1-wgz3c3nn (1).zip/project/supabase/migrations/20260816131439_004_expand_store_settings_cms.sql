/*
# Expand Store Settings for Full Admin CMS

## What changes
Adds columns to `store_settings` for:
- Shipping rules (shipping_type, flat_shipping_cost, free_shipping_threshold)
- Contact information (contact_email, contact_phone, contact_address)
- Store policies (return_policy, shipping_policy, privacy_policy, terms_of_service)
- Homepage content (hero_title, hero_subtitle, hero_image, banner_text, banner_visible)
- Payment settings (upi_enabled, upi_id, cod_enabled, payment_instructions)

## Why
Admin needs to manage ALL store configuration through the UI without editing code or database manually.

## Security
- All columns are admin-only write (existing RLS policy on store_settings).
- SELECT stays available to all authenticated users (checkout reads UPI ID, homepage reads hero content).

## Notes
1. All new columns have safe defaults so existing data is not affected.
2. Default shipping is FREE (shipping_type = 'free', flat_shipping_cost = 0).
3. No existing data is modified or deleted.
*/

ALTER TABLE public.store_settings
  ADD COLUMN IF NOT EXISTS shipping_type text NOT NULL DEFAULT 'free',
  ADD COLUMN IF NOT EXISTS flat_shipping_cost numeric(10,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS free_shipping_threshold numeric(10,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS contact_email text NOT NULL DEFAULT 'support@silora.com',
  ADD COLUMN IF NOT EXISTS contact_phone text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS contact_address text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS return_policy text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS shipping_policy text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS privacy_policy text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS terms_of_service text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS hero_title text NOT NULL DEFAULT 'Timeless Elegance',
  ADD COLUMN IF NOT EXISTS hero_subtitle text NOT NULL DEFAULT 'Discover curated pieces for the modern home',
  ADD COLUMN IF NOT EXISTS hero_image text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS banner_text text NOT NULL DEFAULT 'Free shipping on all orders',
  ADD COLUMN IF NOT EXISTS banner_visible boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS upi_enabled boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS cod_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS payment_instructions text NOT NULL DEFAULT 'Pay using any UPI app and enter your transaction reference ID. We verify payments manually.';

-- Admin can read all profiles (customers) — ensure a SELECT policy exists for admin
-- The existing profiles_select_own_or_admin already covers this, but let's also allow admin to read order_items
-- (already covered by order_items_select_own_or_admin). No changes needed.
