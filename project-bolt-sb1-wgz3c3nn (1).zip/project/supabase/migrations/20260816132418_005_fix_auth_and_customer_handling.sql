/*
# Fix Auth & Customer Account Handling

## What changes
1. Change `orders.user_id` FK from `ON DELETE CASCADE` to `ON DELETE SET NULL` so deleting a customer's auth account preserves order history.
2. Add `admin_delete_customer` SECURITY DEFINER function that deletes a user's auth account (cascades to profile via trigger), while preserving their orders (which get user_id SET NULL).
3. Add `admin_cleanup_orphaned_profiles` function to remove profile rows whose auth.users entry no longer exists.
4. Fix `store_settings` SELECT policy to also allow `anon` role (checkout page needs to read UPI ID without auth).
5. Add `profiles_delete_admin` policy so admin can delete orphaned profiles.

## Security
- `admin_delete_customer`: SECURITY DEFINER, only callable by authenticated admin.
- `admin_cleanup_orphaned_profiles`: SECURITY DEFINER, only callable by admin.
- `store_settings` SELECT: now `TO anon, authenticated` so the anon-key client can read settings.
- `profiles_delete_admin`: admin-only DELETE policy for cleanup.

## Notes
1. No existing data is modified or deleted.
2. Orders with `user_id = NULL` (from deleted customers) are still visible to admin.
3. The `handle_new_user` trigger uses `ON CONFLICT (id) DO NOTHING`, so re-signup creates a fresh profile.
*/

-- 1. Change orders.user_id FK from CASCADE to SET NULL
DO $$
DECLARE
  fk_name text;
BEGIN
  SELECT conname INTO fk_name
  FROM pg_constraint
  WHERE conrelid = 'public.orders'::regclass
    AND contype = 'f'
    AND connamespace = 'public'::regnamespace
    AND conkey[1] = (
      SELECT attnum FROM pg_attribute
      WHERE attrelid = 'public.orders'::regclass
        AND attname = 'user_id'
    );

  IF fk_name IS NOT NULL THEN
    EXECUTE format('ALTER TABLE public.orders DROP CONSTRAINT %I', fk_name);
    EXECUTE 'ALTER TABLE public.orders
      ADD CONSTRAINT orders_user_id_fkey
      FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE SET NULL';
  END IF;
END $$;

-- 2. Admin delete customer function (deletes auth.users entry, preserves orders)
CREATE OR REPLACE FUNCTION public.admin_delete_customer(p_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Permission denied: admin only';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.profiles WHERE id = p_user_id AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Cannot delete admin account';
  END IF;

  DELETE FROM auth.users WHERE id = p_user_id;
END;
$$;

-- 3. Cleanup orphaned profiles (no matching auth.users entry)
CREATE OR REPLACE FUNCTION public.admin_cleanup_orphaned_profiles()
RETURNS bigint
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  deleted_count bigint;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Permission denied: admin only';
  END IF;

  DELETE FROM public.profiles
  WHERE NOT EXISTS (
    SELECT 1 FROM auth.users WHERE auth.users.id = public.profiles.id
  );

  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$;

-- 4. Fix store_settings SELECT to allow anon (checkout reads UPI ID)
DROP POLICY IF EXISTS "store_settings_select_all" ON public.store_settings;
CREATE POLICY "store_settings_select_all" ON public.store_settings
  FOR SELECT TO anon, authenticated USING (true);

-- 5. Add admin DELETE policy on profiles for cleanup
DROP POLICY IF EXISTS "profiles_delete_admin" ON public.profiles;
CREATE POLICY "profiles_delete_admin" ON public.profiles
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- 6. Grant execute on admin functions to authenticated
GRANT EXECUTE ON FUNCTION public.admin_delete_customer(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_cleanup_orphaned_profiles() TO authenticated;
