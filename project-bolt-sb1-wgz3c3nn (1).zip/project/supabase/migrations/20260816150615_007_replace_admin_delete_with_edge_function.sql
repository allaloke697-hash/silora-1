/*
# Replace admin_delete_customer with edge-function-based deletion

## What changes
1. Drop the `admin_delete_customer` SQL function — deletion now happens via the
   `admin-delete-user` Edge Function which calls `supabase.auth.admin.deleteUser()`.
   This properly removes the user from GoTrue's identity index so the same email/phone
   can register again.
2. Keep `admin_cleanup_orphaned_profiles` for manual cleanup of stale profile rows.
3. Keep the `orders.user_id` FK as `ON DELETE SET NULL` (already changed in migration 005).

## Why
The previous `admin_delete_customer` SQL function used `DELETE FROM auth.users` directly.
This removes the Postgres row but does NOT remove the identity from GoTrue's auth service.
GoTrue keeps its own identity index, so the deleted email/phone still shows as "already registered"
when someone tries to sign up again. The Edge Function uses the Admin API which properly
deregisters the identity from GoTrue.

## Security
- The old SQL function is dropped so it can't be called by anyone.
- The Edge Function verifies the caller is an authenticated admin before deleting.
- The Edge Function uses the service role key (never exposed to the frontend).
- Orders are preserved (user_id SET NULL), profiles are auto-deleted (ON DELETE CASCADE).

## Notes
1. No existing data is modified or deleted.
2. The `handle_new_user` trigger uses `ON CONFLICT (id) DO NOTHING`, so re-signup
   with a previously-deleted email creates a fresh profile row.
*/

DROP POLICY IF EXISTS "profiles_delete_admin" ON public.profiles;
DROP FUNCTION IF EXISTS public.admin_delete_customer(uuid);

-- Re-add the admin DELETE policy on profiles (for orphan cleanup only)
DROP POLICY IF EXISTS "profiles_delete_admin" ON public.profiles;
CREATE POLICY "profiles_delete_admin" ON public.profiles
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));
