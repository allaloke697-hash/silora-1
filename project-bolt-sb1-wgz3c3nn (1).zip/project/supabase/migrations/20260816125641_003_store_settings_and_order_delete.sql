/*
# Store Settings + Admin Order Delete + Payment Reference RPC

## What changes
1. Creates `store_settings` table for admin-editable store configuration (UPI ID, store name, etc.).
2. Adds admin-only RLS policies on `store_settings` (read for all authenticated, write for admin only).
3. Adds admin DELETE policy on `orders` so admin can delete orders.
4. Adds admin DELETE policy on `order_items` (cascade already handles this, but explicit policy is safer).
5. Adds a SECURITY DEFINER function `update_payment_reference` so customers can update only the `payment_reference_id` column on their own orders.
6. Seeds a default store_settings row with the current UPI ID.

## Why
- Admin needs to change the UPI ID from the admin panel without touching code.
- Admin needs to delete orders (with confirmation in the UI).
- Customers must only be able to set their payment reference ID, not change payment_status or order_status.

## Security
- `store_settings`: SELECT for all authenticated; INSERT/UPDATE/DELETE for admin only.
- `orders`: adds DELETE for admin. UPDATE stays admin-only (existing policy).
- `update_payment_reference`: SECURITY DEFINER, checks auth.uid() = user_id, only sets payment_reference_id.
*/

-- store_settings table
CREATE TABLE IF NOT EXISTS public.store_settings (
  id integer PRIMARY KEY DEFAULT 1,
  store_name text NOT NULL DEFAULT 'SILORA',
  upi_id text NOT NULL DEFAULT 'silora@upi',
  payment_verification_window text NOT NULL DEFAULT '6:00 PM and 9:00 PM',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT store_settings_singleton CHECK (id = 1)
);

ALTER TABLE public.store_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "store_settings_select_all" ON public.store_settings;
CREATE POLICY "store_settings_select_all" ON public.store_settings
  FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "store_settings_insert_admin" ON public.store_settings;
CREATE POLICY "store_settings_insert_admin" ON public.store_settings
  FOR INSERT TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "store_settings_update_admin" ON public.store_settings;
CREATE POLICY "store_settings_update_admin" ON public.store_settings
  FOR UPDATE TO authenticated USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "store_settings_delete_admin" ON public.store_settings;
CREATE POLICY "store_settings_delete_admin" ON public.store_settings
  FOR DELETE TO authenticated USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

INSERT INTO public.store_settings (id, store_name, upi_id)
VALUES (1, 'SILORA', 'silora@upi')
ON CONFLICT (id) DO NOTHING;

DROP TRIGGER IF EXISTS store_settings_set_updated_at ON public.store_settings;
CREATE TRIGGER store_settings_set_updated_at BEFORE UPDATE ON public.store_settings
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Admin DELETE policy on orders
DROP POLICY IF EXISTS "orders_delete_admin" ON public.orders;
CREATE POLICY "orders_delete_admin" ON public.orders
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- Admin DELETE policy on order_items
DROP POLICY IF EXISTS "order_items_delete_admin" ON public.order_items;
CREATE POLICY "order_items_delete_admin" ON public.order_items
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- SECURITY DEFINER function: customer can update ONLY payment_reference_id on own order
CREATE OR REPLACE FUNCTION public.update_payment_reference(p_order_id uuid, p_reference_id text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM orders WHERE id = p_order_id AND user_id = auth.uid()) THEN
    RAISE EXCEPTION 'You do not have access to this order';
  END IF;

  UPDATE orders
  SET payment_reference_id = p_reference_id
  WHERE id = p_order_id AND user_id = auth.uid();
END;
$$;

GRANT EXECUTE ON FUNCTION public.update_payment_reference(uuid, text) TO authenticated;
